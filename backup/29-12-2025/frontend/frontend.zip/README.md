# SalesDream Frontend (CRA + Tailwind + ag-Grid)

## Setup
1. Create `.env` files as needed (set `REACT_APP_API_BASE=http://localhost:5000/api`).
2. Install deps: `npm install`
3. Start: `npm start`
